-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: users
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2026-05-25 18:48:55.280533'),(2,'auth','0001_initial','2026-05-25 18:48:55.549950'),(3,'admin','0001_initial','2026-05-25 18:48:55.631228'),(4,'admin','0002_logentry_remove_auto_add','2026-05-25 18:48:55.641214'),(5,'admin','0003_logentry_add_action_flag_choices','2026-05-25 18:48:55.661344'),(6,'contenttypes','0002_remove_content_type_name','2026-05-25 18:48:55.720352'),(7,'auth','0002_alter_permission_name_max_length','2026-05-25 18:48:55.753403'),(8,'auth','0003_alter_user_email_max_length','2026-05-25 18:48:55.771358'),(9,'auth','0004_alter_user_username_opts','2026-05-25 18:48:55.780027'),(10,'auth','0005_alter_user_last_login_null','2026-05-25 18:48:55.811920'),(11,'auth','0006_require_contenttypes_0002','2026-05-25 18:48:55.813477'),(12,'auth','0007_alter_validators_add_error_messages','2026-05-25 18:48:55.821158'),(13,'auth','0008_alter_user_username_max_length','2026-05-25 18:48:55.859719'),(14,'auth','0009_alter_user_last_name_max_length','2026-05-25 18:48:55.896195'),(15,'auth','0010_alter_group_name_max_length','2026-05-25 18:48:55.911224'),(16,'auth','0011_update_proxy_permissions','2026-05-25 18:48:55.918095'),(17,'auth','0012_alter_user_first_name_max_length','2026-05-25 18:48:55.954745'),(18,'sessions','0001_initial','2026-05-25 18:48:55.978311'),(19,'bankapp','0001_initial','2026-06-17 15:22:32.315477'),(20,'bankapp','0002_alter_roles_table_alter_users_table','2026-06-17 15:49:02.837553'),(21,'bankapp','0003_users_id_users','2026-06-17 16:02:44.023967'),(22,'bankapp','0004_remove_roles_id_roles_remove_users_id_users','2026-06-17 16:02:44.026806'),(23,'bankapp','0005_clients_levels_of_clients_transactions_and_more','2026-06-18 16:41:22.351022'),(24,'bankapp','0006_clients_db_users_db','2026-06-19 11:00:06.811816'),(25,'bankapp','0007_alter_clients_options_and_more','2026-06-21 08:52:28.009603');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-25  3:35:43
